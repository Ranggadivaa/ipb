<div class="container">
    <h1>Welcome to IPB University</h1>
</div>